# TeamFlow — Architecture

![Architecture diagram](diagrams/architecture.svg)

## Style: Modular Monolith

TeamFlow is built as a single deployable Express service, internally separated into
domain modules (auth/users, projects, tasks, RCA, notifications, export/reporting).

**Why not microservices:** at the scale of "a software engineering org's internal
tool," the domains are small, share the same consistency requirements (a task
status change and its notification must be atomic from the user's point of view),
and are worked on by one team. Microservices would add network calls, distributed
transaction handling, and operational overhead (service discovery, multiple
deploy pipelines) without a corresponding benefit — there's no independent scaling
need between, say, the RCA module and the task module. A modular monolith keeps
module boundaries in code (clear service layer per domain) so it can be split out
later if a specific module (e.g. notifications) genuinely needs to scale
independently.

## Data Store: Relational (SQL)

**SQLite in this reference implementation** (via Node's built-in `node:sqlite`),
**PostgreSQL recommended for production.**

**Why SQL over NoSQL:** the domain is relationship-heavy and consistency-sensitive:
tasks belong to projects, depend on other tasks, carry assignees; RCAs require
*all* assigned reviewers to have decided before closing; notifications must be
deduplicated with a hard uniqueness guarantee. These are exactly the constraints
a relational database enforces natively (foreign keys, unique indexes, multi-table
transactions). A document store would push that referential and transactional
integrity into application code, which is more surface area for the class of bug
this system is specifically trying to prevent (e.g. an RCA closing without every
reviewer's sign-off).

**Tradeoff accepted:** horizontal write-scaling is harder with a relational store
than with most NoSQL options. This is judged acceptable because the workload is
read-heavy dashboards and moderate-volume writes (task/RCA edits), not
high-throughput event ingestion.

## Communication: Synchronous, with One Async Pipeline

All API requests are synchronous request/response — a client updates a task and
gets the new state back in the same call. This keeps the mental model simple and
matches the product stance that "every view always reflects current state"
(no eventual-consistency window for the user to reason about).

The **one deliberately asynchronous flow is notifications**: an event (task
assigned, status changed, RCA submitted, review decision) is logged to the
`notifications` table in a `pending` state *before* dispatch, deduplicated against
a short time-bucketed key, and then dispatched to in-app and/or email channels.
This is asynchronous in effect (a short delivery delay is acceptable, per the
Known Limitations) but is intentionally *not* implemented as a message queue in
this build — at this scale, an in-process pipeline backed by the same
transactional database is simpler to operate and reason about than adding
Kafka/RabbitMQ/SQS. If event volume grew enough to need backpressure or
multi-instance fan-out, this is the module that would be extracted first, with
the queue replacing the direct `notify()` call — the rest of the system already
treats it as an opaque function call, so that swap wouldn't ripple outward.

## File Storage: Object Storage, Not the Database

Attachments store only metadata (`file_name`, `content_type`, `size_bytes`,
`storage_key`) in the relational database; binary content is referenced via
`storage_key` and is expected to live in an S3-compatible bucket. Storing large
binaries in SQL rows bloats the database, slows backups, and doesn't benefit from
a relational engine's strengths. Object storage is built for exactly this shape
of data and scales independently of the application database.

## Reporting

Dashboard endpoints run live aggregation queries against the operational
database rather than a separate analytics warehouse (Product Decision:
Reporting reflects live data). This trades some query latency on very large
projects for the guarantee that dashboard figures are never stale — consistent
with the platform's overall stance that a trustworthy, current view of state
matters more than raw flexibility or maximum query speed.

## Deployment Shape

```
                 ┌──────────────┐
   Browser  ───▶ │  React SPA   │  (static build, served via CDN / static host)
                 └──────┬───────┘
                        │ REST (JSON) over HTTPS
                        ▼
                 ┌──────────────┐
                 │ TeamFlow API │  (Node/Express, stateless, horizontally
                 │  (monolith)  │   replicable behind a load balancer)
                 └──┬────┬───┬──┘
                    │    │   │
        ┌───────────┘    │   └───────────┐
        ▼                ▼               ▼
 ┌─────────────┐  ┌─────────────┐  ┌──────────────┐
 │  PostgreSQL │  │ Object Store │  │ Email Provider│
 │ (primary DB)│  │ (attachments)│  │ (SES/SendGrid)│
 └─────────────┘  └─────────────┘  └──────────────┘
```

The API is stateless (auth token maps directly to a user row; no server-side
session), so multiple instances can run behind a load balancer with the database
as the single source of truth.

## Handling Future Scenarios

- **Offline-first:** would require moving the client to a local-first store
  (e.g. an IndexedDB-backed cache with a sync log) and adding a
  last-write-wins or CRDT-based merge strategy on the API. The append-only
  `activity_log` already gives a natural basis for conflict resolution, since
  every change is timestamped and attributable.
- **Compliance:** the append-only `activity_log` and mandatory RCA sign-off
  workflow are the two features already built for auditability. Adding
  configurable retention policies and export-to-cold-storage for the log would
  extend this without schema changes.
- **High scale:** split the notification pipeline into its own service behind
  a queue first (it's the only naturally async module); add read replicas for
  the dashboard/export queries, which are read-only and tolerate slight
  staleness.
- **Low cost:** the current design (SQLite + a single small VM) is already the
  low-cost baseline; PostgreSQL is only needed once concurrent write volume
  exceeds what SQLite's single-writer model comfortably handles.
- **Multi-region:** would need a primary-region write database with read
  replicas in other regions, and would push object storage to a
  multi-region-replicated bucket. The stateless API tier deploys per-region
  without changes.
