# TeamFlow — Domain Model

![ERD](diagrams/erd.svg)

## Aggregates

The model is organised around five primary aggregates: **Project**, **Task**,
**RCA (Root Cause Analysis)**, **Notification**, and **User**. Supporting
entities (TaskRelation, Attachment, Comment, Review, ActivityLog) hang off
these five.

| Entity | Purpose |
|---|---|
| User | Account, credentials, theme, email preference |
| Project | Container for tasks, members, view preferences |
| ProjectMember | Per-user role within a project (owner/admin/member/viewer) |
| Task | Unit of work: status, priority, assignee, due date, optional parent |
| TaskRelation | Dependency edge between two tasks (`blocks` / `blocked_by`) |
| Attachment | File reference (task or RCA), binary lives in object storage |
| Comment | Discussion entry (task or RCA), with parsed @mentions |
| RCA | Investigation record: severity, lifecycle status |
| RCASection | One of four structured sections per RCA |
| RCAReviewer | Assignment of a reviewer to an RCA |
| Review | A reviewer's decision (approved/rejected) with mandatory comment |
| Notification | A single delivery record for one channel (in-app or email) |
| ActivityLog | Append-only record of every significant state change |

## Key Modelling Decisions

### Tasks that depend on one another

Dependencies are modelled as a **separate `TaskRelation` entity**, not as a
foreign key on `Task` itself, because a task can have multiple predecessors
and multiple successors — a single `blocked_by_task_id` column on `Task`
couldn't express "Task C is blocked by both Task A and Task B." Each row
carries a `relation_type` (`blocks` / `blocked_by`) so the graph can be
queried in either direction efficiently. Cycles are not currently detected at
the schema level (see Known Limitations / Future Improvements — this would be
a validation pass in the service layer, checked as a warning consistent with
the platform's "surface conflicts, don't block saves" philosophy).

### Tasks tracked across more than one project

Every `Task` belongs to exactly one `project_id` — TeamFlow does not model a
single task as living in two projects simultaneously, because that would
break the "single source of truth per view" guarantee (Product Decision:
Multi-view consistency). Instead, cross-project tracking is handled two ways:

1. **Hierarchical breakdown** via `parent_task_id`, which is *not*
   constrained to the same project. A parent initiative in Project A can have
   child tasks that live operationally in Project B's board, while still
   being traceable back to the parent for reporting.
2. **`TaskRelation`** dependency edges are also not constrained to a single
   project, so a task in Project B can be `blocked_by` a task in Project A.

This keeps each task's board/calendar/list membership unambiguous (one
project owns it) while still letting cross-project dependencies and
breakdowns be expressed and queried.

### Why RCA sections are a separate table, not JSON columns on RCA

Each RCA requires exactly four structured sections (timeline, contributing
factors, corrective actions, preventive measures). Modelling these as their
own rows (rather than four columns, or one JSON blob) means: submission
completeness can be checked with a simple query (`sections where content =
''`), a section's edit history can be attributed to a specific
`ActivityLog` entry, and the section list can grow (a fifth section type) as
a data change rather than a schema migration.

### Why Notification is one row per channel, not one row with two flags

A `task_assigned` event may need to reach a user via both in-app and email.
Modelling `Notification` as one row per (user, event, channel) — rather than
one row with `sent_in_app` / `sent_email` booleans — lets the dedupe
constraint be a plain unique index (`dedupe_key + channel`) instead of
conditional logic, and lets each channel's delivery status (`pending` /
`sent` / `failed` / `suppressed`) be tracked independently, since email and
in-app delivery can genuinely fail independently of each other.

### Why ActivityLog stores before/after JSON snapshots

Rather than a generic "field X changed from Y to Z" row per changed field,
each entry stores the whole before/after entity state as JSON. This trades
some storage efficiency for a much simpler write path (one log call per
state-changing operation, not one per field) and makes it trivial to
reconstruct "what did this task look like at time T" for any point in its
history — useful both for audit and for the compliance reporting future
improvement.

### Review is many-to-one with RCA, uniquely constrained per reviewer

`Review` has a unique constraint on `(rca_id, reviewer_id)`: a reviewer gets
exactly one active decision per RCA submission cycle. On resubmission after
`changes_requested`, prior reviews for that RCA are cleared so reviewers
re-decide against the corrected version — this is what lets the mandatory
sign-off rule ("an investigation cannot close until all assigned reviewers
have decided," see Product Decisions) hold across revision cycles rather than
being satisfiable by a stale approval of an earlier draft.
