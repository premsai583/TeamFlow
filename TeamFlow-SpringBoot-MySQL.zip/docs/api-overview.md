# TeamFlow — API / Service Interaction Overview

Base URL (local dev): `http://localhost:4000/api`

Auth: Bearer token in the `Authorization` header. For this reference
implementation the token is simply the authenticated user's id, issued at
register/login (see `backend/src/middleware/auth.js` for the note on
swapping this for signed JWTs in production).

## Auth / Users — `/api/auth`

| Method | Path | Purpose |
|---|---|---|
| POST | `/register` | Create a user, returns a token |
| POST | `/login` | Authenticate, returns a token |
| GET | `/me` | Current user profile |
| PATCH | `/me/theme` | Set light/dark theme |
| PATCH | `/me/email-preference` | Set email opt-out |
| GET/PUT | `/me/view-preference/:projectId` | Per-project, per-user view mode (kanban/calendar/list) |

## Projects — `/api/projects`

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | List projects the current user is a member of |
| POST | `/` | Create a project (creator becomes owner) |
| GET | `/:projectId` | Project detail + members |
| POST | `/:projectId/members` | Add a member with a role |
| GET | `/:projectId/activity` | Recent append-only activity log entries |

## Tasks — `/api/tasks`

| Method | Path | Purpose |
|---|---|---|
| GET | `/project/:projectId` | List tasks, filterable by `status`, `assigneeId`, `priority` |
| POST | `/project/:projectId` | Create a task |
| GET | `/:taskId` | Task detail + relations + comments + attachments |
| PATCH | `/:taskId` | Edit fields (title, assignee, due date, priority, parent) |
| POST | `/:taskId/status` | Transition status (validated against the defined lifecycle) |
| POST | `/:taskId/relations` | Add a dependency edge (`blocks` / `blocked_by`) |
| POST | `/:taskId/comments` | Add a comment (parses @mentions, notifies mentioned users) |
| POST | `/:taskId/attachments` | Register an attachment (binary uploaded to object storage by the client; this stores the resulting key) |

**Status transitions** return the updated task *plus* a `warnings` array
(dependency conflicts, assignee overload) — these never block the save, per
the Task Management requirement.

## RCA — `/api/rca`

| Method | Path | Purpose |
|---|---|---|
| GET | `/project/:projectId` | List RCAs |
| POST | `/project/:projectId` | Create an RCA (creates the four empty sections, assigns initial reviewers) |
| GET | `/:rcaId` | RCA detail: sections, reviewers, reviews |
| PUT | `/:rcaId/sections/:sectionType` | Update one section's content |
| POST | `/:rcaId/reviewers` | Add a reviewer |
| POST | `/:rcaId/reviewers/reassign` | Reassign a reviewer (handles "reviewer unavailable") |
| POST | `/:rcaId/submit` | Submit for review (requires all 4 sections filled + ≥1 reviewer) |
| POST | `/:rcaId/reviews` | Submit a decision (`approved`/`rejected` + mandatory comment) |
| POST | `/:rcaId/comments` | Add a comment on the RCA |

Submitting the final outstanding review triggers the close/changes-requested
transition automatically (see Business Rules doc / design decisions log).

## Notifications — `/api/notifications`

| Method | Path | Purpose |
|---|---|---|
| GET | `/?unreadOnly=true` | List notifications for the current user |
| POST | `/:notificationId/read` | Mark a notification read |

## Export / Reporting — `/api/export`

| Method | Path | Purpose |
|---|---|---|
| GET | `/project/:projectId/tasks.csv` | CSV export, scoped to the same filters as the task list |
| GET | `/project/:projectId/dashboard` | Completion rate, workload by assignee, velocity, RCA volume, overdue count |

## Internal Service Interaction

Routes are thin — they validate input and delegate to a service module per
domain (`taskService`, `rcaService`, `notificationService`, `activityLog`).
Two services call into each other directly (in-process, not over the
network, since this is a monolith):

```
taskService.createTask / updateStatus / updateTask
        │
        ├──▶ activityLog.record()          (every state change)
        └──▶ notificationService.notify()  (assignment, status change)

rcaService.submitForReview / submitReview
        │
        ├──▶ activityLog.record()
        └──▶ notificationService.notify()  (reviewer assigned, decision recorded)

notificationService.notify()
        │
        └──▶ activityLog.record()          (sent / suppressed outcome)
```

This direct-call structure is what would change first if a module were
extracted into its own service — `notify()` becomes a queue publish instead
of a function call, with everything upstream of it unaffected.
