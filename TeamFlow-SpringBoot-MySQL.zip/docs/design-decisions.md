# TeamFlow — Design Decisions Log

Each entry: the decision, alternatives considered, tradeoffs, and rationale.

---

## 1. Architecture style: Modular monolith vs. microservices

**Decision:** Single Express service, internally separated by domain module.

**Alternatives considered:**
- Microservices per aggregate (task service, RCA service, notification service, etc.)
- Serverless functions per endpoint

**Tradeoffs:** Microservices would allow independent scaling and deployment
per domain, at the cost of distributed transactions, network latency between
services, and multiple deploy pipelines to maintain. Serverless would reduce
idle cost but complicates the synchronous, multi-table transactions this
domain needs (e.g. RCA close logic touches `reviews`, `rcas`, and
`activity_log` atomically).

**Rationale:** The domains here are small, share a consistency model, and are
built by a single team. The overhead of distribution isn't justified until a
specific module demonstrably needs to scale independently — most likely
notifications, which is why it's already isolated behind a single `notify()`
call that could become a queue publish without touching callers.

---

## 2. Data store: SQL vs. NoSQL

**Decision:** Relational database (SQLite in dev, PostgreSQL in production).

**Alternatives considered:** MongoDB (document store), DynamoDB (key-value).

**Tradeoffs:** NoSQL options offer easier horizontal write scaling and
schema flexibility. Relational databases enforce referential integrity and
transactional multi-row updates natively, but scale writes less easily and
require migrations for schema changes.

**Rationale:** The core business rules are integrity constraints in
disguise — a task's dependency graph, an RCA's mandatory multi-reviewer
sign-off, and dedup on notifications are exactly the kind of constraints a
relational engine enforces with foreign keys, unique indexes, and
transactions. Recreating that in application code over a document store
shifts risk onto every future change, which conflicts with the project's own
stated priority: enforceable business rules over unconstrained flexibility.

---

## 3. Communication: Synchronous vs. event-driven

**Decision:** Synchronous REST for all reads/writes; one internal
asynchronous pipeline for notifications only.

**Alternatives considered:** Fully event-driven architecture with a message
broker (Kafka/RabbitMQ/SQS) for all cross-module communication.

**Tradeoffs:** A fully event-driven design would decouple modules more
thoroughly and handle burst load more gracefully, at the cost of eventual
consistency (a view might briefly show stale data) and significant
operational complexity (broker infrastructure, retry/DLQ handling,
event schema versioning).

**Rationale:** The product's explicit stance is that every view should
reflect current state without a manual refresh (Multi-view consistency
decision) — synchronous reads make that guarantee trivial. Notifications are
the one place where a short delay is explicitly acceptable (Known
Limitations), so that's the one flow given asynchronous treatment, and even
then it's implemented as an in-process, transactionally-backed pipeline
rather than a full broker, since current volume doesn't justify one.

---

## 4. File storage: Object storage vs. database BLOBs

**Decision:** Attachment binaries live in S3-compatible object storage;
the database stores only metadata and a storage key.

**Alternatives considered:** Storing file bytes directly as BLOB columns.

**Tradeoffs:** BLOBs simplify the mental model (one datastore) but bloat
the database, slow down backups/replication, and don't benefit from a
relational engine's transactional strengths.

**Rationale:** Object storage is purpose-built for this access pattern
(large, infrequently-updated binary blobs served directly to clients) and
scales independently of the operational database.

---

## 5. Task status lifecycle: Fixed transitions vs. free-form status field

**Decision:** A defined set of allowed transitions
(`todo → in_progress → in_review → done`, with `blocked` reachable from any
active state) enforced server-side.

**Alternatives considered:** A free-text or unconstrained enum status field
that any client can set to any value.

**Tradeoffs:** Fixed transitions mean occasional friction — a valid
real-world shortcut ("mark done directly from todo because it was trivial")
requires an explicit intermediate step. Unconstrained status would allow that
flexibility but permits ad-hoc jumps that make project history unreliable.

**Rationale:** Matches the product's own tradeoff analysis (Task
progression decision): less flexibility in exchange for a project history
that can be trusted without question. Every transition is logged with full
before/after state regardless.

---

## 6. Dependency conflicts and assignee overload: Warn vs. block

**Decision:** Both are surfaced as non-blocking warnings returned alongside
a successful save.

**Alternatives considered:** Hard-blocking the save until the conflict is
resolved (e.g. refusing to mark a task `in_progress` while a blocking
predecessor is unfinished).

**Tradeoffs:** Blocking would guarantee the dependency graph and workload
limits are never violated, but real teams sometimes need to work around a
stale or incorrectly modelled dependency, and a hard block with no override
tends to get worked around by users abandoning the tool rather than fixing
the model.

**Rationale:** The requirement explicitly calls for warnings, not blocks
("Dependency conflicts and assignee overload are surfaced as warnings without
blocking saves"). This keeps the system informative without becoming an
obstacle to getting work done.

---

## 7. RCA sign-off: Single approver vs. mandatory multi-reviewer consensus

**Decision:** An RCA cannot close until every assigned reviewer has
submitted a decision; any single rejection sends it to `changes_requested`
rather than closing.

**Alternatives considered:** First-decision-wins (closes as soon as one
reviewer approves), or majority vote among reviewers.

**Tradeoffs:** Requiring unanimity-of-participation (not unanimity of
approval, but universal participation) takes longer to resolve than a
first-decision or majority model, which matters for time-sensitive
incidents.

**Rationale:** Matches the product's stated priority that "no RCA can be
dismissed without documented sign-off" over speed of resolution. A single
rejection blocking closure (rather than being outvoted) ensures a
reviewer's documented concern about a root-cause investigation can't be
silently overridden.

---

## 8. Notification deduplication: Time-bucketed hash vs. exact-duplicate detection

**Decision:** Notifications are deduplicated via a hash of
`(user, event type, entity, channel, time bucket)`, enforced by a unique
database index, checked *before* dispatch.

**Alternatives considered:** Deduplicating only exact repeat calls (same
event fired twice in the same millisecond), or deduplicating at the client
by hiding visually identical alerts.

**Tradeoffs:** Time-bucketing (5-minute windows in this implementation)
means two *genuinely distinct* occurrences of the same event type on the
same entity within the window would also be collapsed into one alert. This
is accepted because the scenario driving this rule — a processing lag
firing the same underlying event twice — is exactly what should collapse,
and two truly independent status changes on the same task within 5 minutes
is a rare enough case that a single consolidated alert is still useful
information, not lost information.

**Rationale:** Enforcing this at the database layer (a unique index, not an
application-level check-then-insert) is what actually gives the constraint
teeth. Client-side deduplication would only mask the problem in the UI
while still sending duplicate emails, which the product decision (log
before dispatch, suppress duplicates) explicitly calls out as unacceptable.

---

## 9. Cross-project tasks: Single project ownership vs. many-to-many project membership

**Decision:** A task belongs to exactly one project; cross-project
relationships are expressed via `parent_task_id` (not project-constrained)
and `TaskRelation` dependency edges (also not project-constrained).

**Alternatives considered:** A many-to-many join table letting one task
appear in multiple projects' boards simultaneously.

**Tradeoffs:** Many-to-many task/project membership would make "this
epic spans three projects" easier to model directly, but breaks the
guarantee that every view reads from one unambiguous source per task
(which project's Kanban column does a shared task "belong" to when its
status changes?).

**Rationale:** Chosen to preserve the Multi-view consistency decision.
Hierarchical breakdown and cross-project dependency edges cover the
practical need (tracking related work across project boundaries) without
introducing ownership ambiguity.

---

## 10. Reporting: Live aggregation vs. a separate analytics store

**Decision:** Dashboard endpoints run aggregation queries directly against
the operational database on each request.

**Alternatives considered:** A nightly ETL into a separate analytics
database or data warehouse; a caching layer with periodic refresh.

**Tradeoffs:** Live aggregation means dashboard load time scales with
project size and can degrade on very large projects (acknowledged in Known
Limitations). A warehouse or cache would keep dashboards fast at any scale
but introduces a staleness window and a second system to keep in sync.

**Rationale:** Matches the product decision that dashboard figures should
always reflect current data. For the target scale (a single engineering
org's projects, not a multi-tenant SaaS with millions of tasks), correctly
scoped and indexed live queries perform acceptably, as confirmed in
evaluation. This is the first place to revisit if a customer's data volume
grows past what live queries handle comfortably.
