# TeamFlow - React + Spring Boot + MySQL

## Tech Stack
- Frontend: React.js + Vite
- Backend: Spring Boot
- Database: MySQL
- Styling: CSS
- Deployment: Docker + Docker Compose
- Testing: JUnit 5 / Spring Boot Test
- Architecture: Modular Monolith

## How to run like a beginner

### Method 1: Docker, easiest
1. Install Docker Desktop.
2. Open this `TeamFlow-SpringBoot` folder in VS Code.
3. Open terminal in VS Code.
4. Run:

```bash
docker compose up --build
```

5. Open browser:

```text
http://localhost:5173
```

6. Demo login:

```text
Email: prem@example.com
Password: password
```

### Method 2: Without Docker
1. Install Java 17.
2. Install MySQL.
3. Create database:

```sql
CREATE DATABASE teamflow;
```

4. Start backend:

```bash
cd backend
mvn spring-boot:run
```

5. Start frontend in another terminal:

```bash
cd frontend
npm install
npm run dev
```

6. Open:

```text
http://localhost:5173
```

## Backend modules
- `model` = database entities
- `repo` = database access using Spring Data JPA
- `controller` = REST APIs
- `service` = business/helper logic
- `config` = CORS and seed data

## Main APIs
- `/api/auth/register`
- `/api/auth/login`
- `/api/projects`
- `/api/tasks/project/{projectId}`
- `/api/rca/project/{projectId}`
- `/api/notifications`
- `/api/export/project/{projectId}/dashboard`
- `/api/export/project/{projectId}/tasks.csv`

## Features included
- User register/login
- Projects
- Kanban/List/Calendar task views from React frontend
- Task create/update/status change
- Task comments
- Task dependencies
- RCA create/submit/review
- Notifications
- Dashboard analytics
- CSV export
- Light/dark theme

## Known limitations
- Authentication is simple token-based in memory for assignment/demo use.
- Email sending is represented by notification records; real SMTP can be added later.
- File upload table is not fully implemented in this simplified Spring Boot conversion.
