import React, { useEffect, useState, useCallback } from 'react';
import { api, isLoggedIn, clearToken } from './api.js';
import AuthScreen from './components/AuthScreen.jsx';
import KanbanBoard from './components/KanbanBoard.jsx';
import ListView from './components/ListView.jsx';
import CalendarView from './components/CalendarView.jsx';
import TaskModal from './components/TaskModal.jsx';
import NewTaskModal from './components/NewTaskModal.jsx';
import RCAPanel from './components/RCAPanel.jsx';
import NotificationBell from './components/NotificationBell.jsx';
import Dashboard from './components/Dashboard.jsx';

const VIEWS = ['kanban', 'list', 'calendar', 'rca', 'dashboard'];

export default function App() {
  const [user, setUser] = useState(null);
  const [checkedAuth, setCheckedAuth] = useState(false);
  const [projects, setProjects] = useState([]);
  const [activeProjectId, setActiveProjectId] = useState(null);
  const [view, setView] = useState('kanban');
  const [tasks, setTasks] = useState([]);
  const [filters, setFilters] = useState({});
  const [openTaskId, setOpenTaskId] = useState(null);
  const [creatingTask, setCreatingTask] = useState(false);
  const [theme, setThemeState] = useState('light');
  const [newProjectName, setNewProjectName] = useState('');

  useEffect(() => {
    if (isLoggedIn()) {
      api.me().then((r) => { setUser(r.user); setThemeState(r.user.theme || 'light'); }).catch(() => clearToken()).finally(() => setCheckedAuth(true));
    } else {
      setCheckedAuth(true);
    }
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const loadProjects = useCallback(async () => {
    const { projects } = await api.listProjects();
    setProjects(projects);
    if (!activeProjectId && projects.length > 0) setActiveProjectId(projects[0].id);
  }, [activeProjectId]);

  useEffect(() => { if (user) loadProjects(); }, [user, loadProjects]);

  const loadTasks = useCallback(async () => {
    if (!activeProjectId) return;
    const { tasks } = await api.listTasks(activeProjectId, filters);
    setTasks(tasks);
  }, [activeProjectId, filters]);

  useEffect(() => { loadTasks(); }, [loadTasks]);

  async function toggleTheme() {
    const next = theme === 'light' ? 'dark' : 'light';
    setThemeState(next);
    try { await api.setTheme(next); } catch { /* non-fatal */ }
  }

  async function createProject(e) {
    e.preventDefault();
    if (!newProjectName.trim()) return;
    const { project } = await api.createProject(newProjectName);
    setNewProjectName('');
    await loadProjects();
    setActiveProjectId(project.id);
  }

  if (!checkedAuth) return null;
  if (!user) return <AuthScreen onAuthed={(u) => { setUser(u); }} />;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <h3>TeamFlow</h3>
        <form onSubmit={createProject} style={{ marginBottom: 12 }}>
          <input
            placeholder="New project name"
            value={newProjectName}
            onChange={(e) => setNewProjectName(e.target.value)}
            style={{ width: '100%', marginBottom: 6 }}
          />
          <button type="submit" style={{ width: '100%' }} className="secondary">+ Create project</button>
        </form>
        {projects.map((p) => (
          <div
            key={p.id}
            onClick={() => setActiveProjectId(p.id)}
            style={{
              padding: '8px 10px', borderRadius: 8, cursor: 'pointer', marginBottom: 4,
              background: p.id === activeProjectId ? 'var(--surface-2)' : 'transparent',
              fontWeight: p.id === activeProjectId ? 700 : 400, fontSize: 14,
            }}
          >
            {p.name}
          </div>
        ))}
        <div style={{ marginTop: 24, fontSize: 13, color: 'var(--text-muted)' }}>
          Signed in as {user.name || user.email}
          <br />
          <a href="#" onClick={(e) => { e.preventDefault(); clearToken(); setUser(null); }}>Sign out</a>
        </div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div className="view-tabs">
            {VIEWS.map((v) => (
              <button key={v} className={view === v ? '' : 'inactive'} onClick={() => setView(v)}>
                {v[0].toUpperCase() + v.slice(1)}
              </button>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {view !== 'rca' && view !== 'dashboard' && (
              <button onClick={() => setCreatingTask(true)}>+ New Task</button>
            )}
            <button className="secondary" onClick={toggleTheme}>{theme === 'light' ? '🌙 Dark' : '☀️ Light'}</button>
            <NotificationBell />
          </div>
        </div>

        {!activeProjectId && <p>Create or select a project to get started.</p>}

        {activeProjectId && view === 'kanban' && <KanbanBoard tasks={tasks} onOpenTask={setOpenTaskId} />}
        {activeProjectId && view === 'list' && (
          <ListView tasks={tasks} projectId={activeProjectId} onOpenTask={setOpenTaskId} filters={filters} setFilters={setFilters} />
        )}
        {activeProjectId && view === 'calendar' && <CalendarView tasks={tasks} onOpenTask={setOpenTaskId} />}
        {activeProjectId && view === 'rca' && <RCAPanel projectId={activeProjectId} currentUser={user} />}
        {activeProjectId && view === 'dashboard' && <Dashboard projectId={activeProjectId} />}

        {openTaskId && (
          <TaskModal taskId={openTaskId} onClose={() => setOpenTaskId(null)} onChanged={loadTasks} />
        )}
        {creatingTask && (
          <NewTaskModal projectId={activeProjectId} onClose={() => setCreatingTask(false)} onCreated={() => { setCreatingTask(false); loadTasks(); }} />
        )}
      </main>
    </div>
  );
}
