import React, { useState } from 'react';
import { api } from '../api.js';

export default function NewTaskModal({ projectId, onClose, onCreated }) {
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState('medium');
  const [dueDate, setDueDate] = useState('');
  const [warnings, setWarnings] = useState([]);

  async function submit(e) {
    e.preventDefault();
    const result = await api.createTask(projectId, { title, priority, dueDate: dueDate || undefined });
    if (result.warnings?.length) {
      setWarnings(result.warnings);
      setTimeout(() => onCreated(), 800);
    } else {
      onCreated();
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <form className="modal" style={{ width: 400 }} onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <h3 style={{ marginTop: 0 }}>New Task</h3>
        {warnings.map((w, i) => <div key={i} className="warning-banner">⚠ {w.message}</div>)}
        <div style={{ marginBottom: 10 }}>
          <input placeholder="Title" style={{ width: '100%' }} value={title} onChange={(e) => setTitle(e.target.value)} required autoFocus />
        </div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
          <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button type="button" className="secondary" onClick={onClose}>Cancel</button>
          <button type="submit">Create</button>
        </div>
      </form>
    </div>
  );
}
