import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Dashboard({ projectId }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.getDashboard(projectId).then(setData);
  }, [projectId]);

  if (!data) return <p>Loading dashboard…</p>;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14 }}>
      <div className="card">
        <h4 style={{ marginTop: 0 }}>Completion rate</h4>
        <div style={{ fontSize: 28, fontWeight: 700 }}>{data.completionRate.percentage}%</div>
        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{data.completionRate.done} of {data.completionRate.total} tasks done</div>
      </div>
      <div className="card">
        <h4 style={{ marginTop: 0 }}>Workload per assignee</h4>
        {data.workloadByAssignee.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No active assignments.</p>}
        {data.workloadByAssignee.map((w) => (
          <div key={w.assignee_id} style={{ fontSize: 13 }}>{w.assignee_id}: {w.active_tasks} active</div>
        ))}
      </div>
      <div className="card">
        <h4 style={{ marginTop: 0 }}>Velocity (last 14 days)</h4>
        {data.velocity.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No completions recorded yet.</p>}
        {data.velocity.map((v) => (
          <div key={v.day} style={{ fontSize: 13 }}>{v.day}: {v.completed} completed</div>
        ))}
      </div>
      <div className="card">
        <h4 style={{ marginTop: 0 }}>RCA volume</h4>
        {data.rcaVolume.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No investigations yet.</p>}
        {data.rcaVolume.map((r) => (
          <div key={r.status} style={{ fontSize: 13 }}>{r.status.replace('_', ' ')}: {r.count}</div>
        ))}
      </div>
      <div className="card">
        <h4 style={{ marginTop: 0 }}>Project health</h4>
        <div style={{ fontSize: 13 }}>Overdue tasks: <strong>{data.projectHealth.overdueTasks}</strong></div>
      </div>
    </div>
  );
}
