import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

const SECTION_LABELS = {
  timeline: 'Timeline',
  contributing_factors: 'Contributing Factors',
  corrective_actions: 'Corrective Actions',
  preventive_measures: 'Preventive Measures',
};

export default function RCAPanel({ projectId, currentUser }) {
  const [rcas, setRcas] = useState([]);
  const [selected, setSelected] = useState(null);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');

  async function loadList() {
    const { rcas } = await api.listRCAs(projectId);
    setRcas(rcas);
  }
  useEffect(() => { loadList(); }, [projectId]);

  async function openRCA(id) {
    const { rca } = await api.getRCA(id);
    setSelected(rca);
    setError('');
  }

  async function saveSection(sectionType, content) {
    const { rca } = await api.updateRCASection(selected.id, sectionType, content);
    setSelected(rca);
  }

  async function submit() {
    try {
      const { rca } = await api.submitRCA(selected.id);
      setSelected(rca);
      loadList();
    } catch (err) {
      setError(err.message);
    }
  }

  async function decide(decision) {
    const comment = prompt(`Comment for your ${decision} decision (required):`);
    if (!comment || !comment.trim()) return;
    try {
      const { rca } = await api.submitReview(selected.id, decision, comment);
      setSelected(rca);
      loadList();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div style={{ display: 'flex', gap: 20 }}>
      <div style={{ width: 260, flexShrink: 0 }}>
        <button style={{ marginBottom: 12, width: '100%' }} onClick={() => setCreating(true)}>+ New RCA</button>
        {rcas.map((r) => (
          <div key={r.id} className="card" style={{ marginBottom: 8, cursor: 'pointer' }} onClick={() => openRCA(r.id)}>
            <strong style={{ fontSize: 14 }}>{r.title}</strong>
            <div style={{ marginTop: 6 }}>
              <span className={`status-pill status-${r.status}`}>{r.status.replace('_', ' ')}</span>
            </div>
          </div>
        ))}
        {rcas.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No investigations yet.</p>}
      </div>

      <div style={{ flex: 1 }}>
        {creating && <NewRCAForm projectId={projectId} onClose={() => setCreating(false)} onCreated={() => { setCreating(false); loadList(); }} />}
        {selected && !creating && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ margin: 0 }}>{selected.title}</h3>
              <span className={`status-pill status-${selected.status}`}>{selected.status.replace('_', ' ')}</span>
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Severity: {selected.severity}</p>
            {error && <div className="warning-banner" style={{ borderColor: 'var(--danger)' }}>{error}</div>}

            {selected.sections.map((s) => (
              <div className="rca-section" key={s.section_type}>
                <label>{SECTION_LABELS[s.section_type]}</label>
                <textarea
                  defaultValue={s.content}
                  disabled={selected.status === 'closed' || selected.status === 'in_review'}
                  onBlur={(e) => saveSection(s.section_type, e.target.value)}
                />
              </div>
            ))}

            <div style={{ marginBottom: 14 }}>
              <strong style={{ fontSize: 13 }}>Reviewers</strong>
              <ul style={{ fontSize: 13 }}>
                {selected.reviewers.map((r) => {
                  const review = selected.reviews.find((rv) => rv.reviewer_id === r.id);
                  return (
                    <li key={r.id}>
                      {r.name} — {review ? <strong>{review.decision}</strong> : 'pending'}
                    </li>
                  );
                })}
              </ul>
            </div>

            {(selected.status === 'draft' || selected.status === 'changes_requested') && (
              <button onClick={submit}>Submit for review</button>
            )}

            {selected.status === 'in_review' && currentUser && selected.reviewers.some((r) => r.id === currentUser.id) &&
              !selected.reviews.some((rv) => rv.reviewer_id === currentUser.id) && (
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => decide('approved')}>Approve</button>
                  <button className="danger" onClick={() => decide('rejected')}>Reject</button>
                </div>
            )}
          </div>
        )}
        {!selected && !creating && <p style={{ color: 'var(--text-muted)' }}>Select an investigation to view details.</p>}
      </div>
    </div>
  );
}

function NewRCAForm({ projectId, onClose, onCreated }) {
  const [title, setTitle] = useState('');
  const [severity, setSeverity] = useState('medium');
  const [members, setMembers] = useState([]);
  const [reviewerIds, setReviewerIds] = useState([]);

  useEffect(() => {
    api.getProject(projectId).then((data) => setMembers(data.members));
  }, [projectId]);

  function toggleReviewer(id) {
    setReviewerIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  async function submit(e) {
    e.preventDefault();
    await api.createRCA(projectId, { title, severity, reviewerIds });
    onCreated();
  }

  return (
    <form className="card" onSubmit={submit}>
      <h3 style={{ marginTop: 0 }}>New RCA</h3>
      <div style={{ marginBottom: 10 }}>
        <input placeholder="Title" style={{ width: '100%' }} value={title} onChange={(e) => setTitle(e.target.value)} required />
      </div>
      <div style={{ marginBottom: 10 }}>
        <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="critical">Critical</option>
        </select>
      </div>
      <div style={{ marginBottom: 14 }}>
        <strong style={{ fontSize: 13 }}>Assign reviewers</strong>
        {members.map((m) => (
          <label key={m.id} style={{ display: 'block', fontSize: 13 }}>
            <input type="checkbox" checked={reviewerIds.includes(m.id)} onChange={() => toggleReviewer(m.id)} /> {m.name}
          </label>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button type="button" className="secondary" onClick={onClose}>Cancel</button>
        <button type="submit">Create</button>
      </div>
    </form>
  );
}
