import React, { useState, useMemo } from 'react';
import { getToken } from '../api.js';

export default function ListView({ tasks, projectId, onOpenTask, filters, setFilters }) {
  const [sortKey, setSortKey] = useState('due_date');

  const sorted = useMemo(() => {
    const copy = [...tasks];
    copy.sort((a, b) => {
      const av = a[sortKey] || '';
      const bv = b[sortKey] || '';
      return av < bv ? -1 : av > bv ? 1 : 0;
    });
    return copy;
  }, [tasks, sortKey]);

  async function exportCSV() {
    const qs = new URLSearchParams(filters).toString();
    const res = await fetch(`/api/export/project/${projectId}/tasks.csv${qs ? `?${qs}` : ''}`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tasks_export.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <select value={filters.status || ''} onChange={(e) => setFilters({ ...filters, status: e.target.value || undefined })}>
          <option value="">All statuses</option>
          <option value="todo">To Do</option>
          <option value="in_progress">In Progress</option>
          <option value="in_review">In Review</option>
          <option value="blocked">Blocked</option>
          <option value="done">Done</option>
        </select>
        <select value={filters.priority || ''} onChange={(e) => setFilters({ ...filters, priority: e.target.value || undefined })}>
          <option value="">All priorities</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="urgent">Urgent</option>
        </select>
        <select value={sortKey} onChange={(e) => setSortKey(e.target.value)}>
          <option value="due_date">Sort by due date</option>
          <option value="priority">Sort by priority</option>
          <option value="title">Sort by title</option>
          <option value="status">Sort by status</option>
        </select>
        <button className="secondary" onClick={exportCSV}>Export CSV (active filters)</button>
      </div>
      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead>
            <tr>
              <th>Title</th><th>Status</th><th>Priority</th><th>Due date</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((t) => (
              <tr key={t.id} onClick={() => onOpenTask(t.id)} style={{ cursor: 'pointer' }}>
                <td>{t.title}</td>
                <td>{t.status.replace('_', ' ')}</td>
                <td><span className={`priority-badge priority-${t.priority}`}>{t.priority}</span></td>
                <td>{t.due_date || '—'}</td>
              </tr>
            ))}
            {sorted.length === 0 && (
              <tr><td colSpan={4} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No tasks match these filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
