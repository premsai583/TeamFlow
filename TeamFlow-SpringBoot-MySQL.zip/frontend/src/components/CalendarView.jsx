import React, { useMemo, useState } from 'react';

function daysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

export default function CalendarView({ tasks, onOpenTask }) {
  const [cursor, setCursor] = useState(new Date());
  const year = cursor.getFullYear();
  const month = cursor.getMonth();

  const tasksByDate = useMemo(() => {
    const map = {};
    for (const t of tasks) {
      if (!t.due_date) continue;
      const key = t.due_date.slice(0, 10);
      map[key] = map[key] || [];
      map[key].push(t);
    }
    return map;
  }, [tasks]);

  const firstWeekday = new Date(year, month, 1).getDay();
  const totalDays = daysInMonth(year, month);
  const cells = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= totalDays; d++) cells.push(d);

  const monthLabel = cursor.toLocaleString('default', { month: 'long', year: 'numeric' });

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <button className="secondary" onClick={() => setCursor(new Date(year, month - 1, 1))}>‹ Prev</button>
        <strong>{monthLabel}</strong>
        <button className="secondary" onClick={() => setCursor(new Date(year, month + 1, 1))}>Next ›</button>
      </div>
      <div className="calendar-grid">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
          <div key={d} style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)' }}>{d}</div>
        ))}
        {cells.map((day, idx) => {
          if (!day) return <div key={idx} />;
          const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const dayTasks = tasksByDate[dateStr] || [];
          return (
            <div key={idx} className="calendar-cell">
              <div className="date-label">{day}</div>
              {dayTasks.slice(0, 3).map((t) => (
                <div
                  key={t.id}
                  onClick={() => onOpenTask(t.id)}
                  style={{ cursor: 'pointer', fontSize: 11, marginTop: 2, padding: '2px 4px', background: 'var(--surface-2)', borderRadius: 4 }}
                >
                  {t.title}
                </div>
              ))}
              {dayTasks.length > 3 && <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>+{dayTasks.length - 3} more</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
