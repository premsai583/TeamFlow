import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);

  async function load() {
    const { notifications } = await api.listNotifications();
    setNotifications(notifications);
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000); // poll for in-app delivery
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  async function openPanel() {
    setOpen((o) => !o);
  }

  async function markRead(id) {
    await api.markNotificationRead(id);
    load();
  }

  return (
    <div style={{ position: 'relative' }}>
      <button className="secondary" onClick={openPanel} style={{ position: 'relative' }}>
        🔔 {unreadCount > 0 && <span className="badge-dot">{unreadCount}</span>}
      </button>
      {open && (
        <div className="notif-panel card">
          {notifications.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No notifications yet.</p>}
          {notifications.map((n) => (
            <div key={n.id} className={`notif-item ${n.read ? '' : 'unread'}`} onClick={() => markRead(n.id)} style={{ cursor: 'pointer' }}>
              <div>{n.message}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{n.channel} · {n.status} · {new Date(n.created_at).toLocaleString()}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
