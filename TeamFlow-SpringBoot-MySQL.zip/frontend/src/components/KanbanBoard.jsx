import React from 'react';

const COLUMNS = [
  { key: 'todo', label: 'To Do' },
  { key: 'in_progress', label: 'In Progress' },
  { key: 'in_review', label: 'In Review' },
  { key: 'blocked', label: 'Blocked' },
  { key: 'done', label: 'Done' },
];

export default function KanbanBoard({ tasks, onOpenTask }) {
  return (
    <div className="kanban-board">
      {COLUMNS.map((col) => (
        <div key={col.key} className="kanban-column">
          <h3>{col.label} ({tasks.filter((t) => t.status === col.key).length})</h3>
          {tasks
            .filter((t) => t.status === col.key)
            .map((task) => (
              <div key={task.id} className="task-card" onClick={() => onOpenTask(task.id)}>
                <strong>{task.title}</strong>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>
                  {task.due_date ? `Due ${task.due_date}` : 'No due date'}
                </div>
                <span className={`priority-badge priority-${task.priority}`}>{task.priority}</span>
              </div>
            ))}
        </div>
      ))}
    </div>
  );
}
