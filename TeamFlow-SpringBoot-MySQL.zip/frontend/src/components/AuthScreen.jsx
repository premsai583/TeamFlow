import React, { useState } from 'react';
import { api, setToken } from '../api.js';

export default function AuthScreen({ onAuthed }) {
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('alice@teamflow.dev');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = mode === 'login' ? await api.login(email, password) : await api.register(name, email, password);
      setToken(result.token);
      onAuthed(result.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', alignItems: 'center', justifyContent: 'center' }}>
      <form onSubmit={submit} className="card" style={{ width: 360 }}>
        <h2 style={{ marginTop: 0 }}>TeamFlow</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: -8 }}>
          {mode === 'login' ? 'Sign in to continue' : 'Create your account'}
        </p>
        {mode === 'register' && (
          <div style={{ marginBottom: 10 }}>
            <input placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} style={{ width: '100%' }} required />
          </div>
        )}
        <div style={{ marginBottom: 10 }}>
          <input placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} style={{ width: '100%' }} required />
        </div>
        <div style={{ marginBottom: 14 }}>
          <input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: '100%' }} required />
        </div>
        {error && <div className="warning-banner">{error}</div>}
        <button type="submit" style={{ width: '100%' }} disabled={loading}>
          {loading ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}
        </button>
        <p style={{ fontSize: 13, marginTop: 12, textAlign: 'center' }}>
          {mode === 'login' ? (
            <>No account? <a href="#" onClick={(e) => { e.preventDefault(); setMode('register'); }}>Register</a></>
          ) : (
            <>Have an account? <a href="#" onClick={(e) => { e.preventDefault(); setMode('login'); }}>Sign in</a></>
          )}
        </p>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
          Demo: alice@teamflow.dev / password123 (after running the seed script)
        </p>
      </form>
    </div>
  );
}
