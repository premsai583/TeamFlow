import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

const NEXT_STATUSES = {
  todo: ['in_progress', 'blocked'],
  in_progress: ['in_review', 'blocked', 'todo'],
  in_review: ['done', 'in_progress', 'blocked'],
  blocked: ['todo', 'in_progress'],
  done: [],
};

export default function TaskModal({ taskId, onClose, onChanged }) {
  const [data, setData] = useState(null);
  const [warnings, setWarnings] = useState([]);
  const [commentBody, setCommentBody] = useState('');
  const [error, setError] = useState('');

  async function load() {
    const result = await api.getTask(taskId);
    setData(result);
  }

  useEffect(() => { load(); }, [taskId]);

  async function changeStatus(status) {
    setError('');
    try {
      const result = await api.updateTaskStatus(taskId, status);
      setWarnings(result.warnings || []);
      await load();
      onChanged?.();
    } catch (err) {
      setError(err.message);
    }
  }

  async function postComment() {
    if (!commentBody.trim()) return;
    await api.addTaskComment(taskId, commentBody);
    setCommentBody('');
    await load();
  }

  if (!data) return null;
  const { task, comments, relations } = data;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <h3 style={{ marginTop: 0 }}>{task.title}</h3>
          <button className="secondary" onClick={onClose}>Close</button>
        </div>
        <p style={{ color: 'var(--text-muted)' }}>{task.description || 'No description.'}</p>

        <div style={{ display: 'flex', gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
          <span className={`priority-badge priority-${task.priority}`}>{task.priority}</span>
          <span style={{ fontSize: 13 }}>Status: <strong>{task.status.replace('_', ' ')}</strong></span>
          {task.due_date && <span style={{ fontSize: 13 }}>Due: {task.due_date}</span>}
        </div>

        {warnings.map((w, i) => (
          <div key={i} className="warning-banner">⚠ {w.message}</div>
        ))}
        {error && <div className="warning-banner" style={{ borderColor: 'var(--danger)' }}>{error}</div>}

        <div style={{ marginBottom: 14 }}>
          {(NEXT_STATUSES[task.status] || []).map((s) => (
            <button key={s} className="secondary" style={{ marginRight: 6 }} onClick={() => changeStatus(s)}>
              Move to {s.replace('_', ' ')}
            </button>
          ))}
          {(NEXT_STATUSES[task.status] || []).length === 0 && (
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Terminal status — no further transitions.</span>
          )}
        </div>

        {relations && relations.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <strong style={{ fontSize: 13 }}>Dependencies</strong>
            <ul style={{ fontSize: 13 }}>
              {relations.map((r) => (
                <li key={r.id}>
                  {r.task_id === task.id ? r.relation_type : `depended on by (${r.relation_type})`} — {r.related_task_id === task.id ? r.task_id : r.related_task_id}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div>
          <strong style={{ fontSize: 13 }}>Comments</strong>
          <div style={{ maxHeight: 160, overflowY: 'auto', margin: '8px 0' }}>
            {comments.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No comments yet.</p>}
            {comments.map((c) => (
              <div key={c.id} style={{ fontSize: 13, marginBottom: 6, borderBottom: '1px solid var(--border)', paddingBottom: 6 }}>
                {c.body}
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <input
              style={{ flex: 1 }}
              placeholder="Add a comment (@mention a teammate)"
              value={commentBody}
              onChange={(e) => setCommentBody(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && postComment()}
            />
            <button onClick={postComment}>Post</button>
          </div>
        </div>
      </div>
    </div>
  );
}
