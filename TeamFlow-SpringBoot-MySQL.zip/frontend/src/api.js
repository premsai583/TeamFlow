const BASE = '/api';

function getToken() {
  return localStorage.getItem('teamflow_token');
}

async function request(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const isJson = res.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await res.json() : await res.text();

  if (!res.ok) {
    throw new Error((data && data.error) || `Request failed: ${res.status}`);
  }
  return data;
}

export const api = {
  register: (name, email, password) => request('/auth/register', { method: 'POST', body: { name, email, password } }),
  login: (email, password) => request('/auth/login', { method: 'POST', body: { email, password } }),
  me: () => request('/auth/me'),
  setTheme: (theme) => request('/auth/me/theme', { method: 'PATCH', body: { theme } }),

  listProjects: () => request('/projects'),
  createProject: (name, description) => request('/projects', { method: 'POST', body: { name, description } }),
  getProject: (id) => request(`/projects/${id}`),
  getActivity: (id) => request(`/projects/${id}/activity`),

  listTasks: (projectId, filters = {}) => {
    const qs = new URLSearchParams(filters).toString();
    return request(`/tasks/project/${projectId}${qs ? `?${qs}` : ''}`);
  },
  createTask: (projectId, payload) => request(`/tasks/project/${projectId}`, { method: 'POST', body: payload }),
  getTask: (taskId) => request(`/tasks/${taskId}`),
  updateTask: (taskId, payload) => request(`/tasks/${taskId}`, { method: 'PATCH', body: payload }),
  updateTaskStatus: (taskId, status) => request(`/tasks/${taskId}/status`, { method: 'POST', body: { status } }),
  addRelation: (taskId, relatedTaskId, relationType) =>
    request(`/tasks/${taskId}/relations`, { method: 'POST', body: { relatedTaskId, relationType } }),
  addTaskComment: (taskId, body) => request(`/tasks/${taskId}/comments`, { method: 'POST', body: { body } }),

  listRCAs: (projectId) => request(`/rca/project/${projectId}`),
  createRCA: (projectId, payload) => request(`/rca/project/${projectId}`, { method: 'POST', body: payload }),
  getRCA: (rcaId) => request(`/rca/${rcaId}`),
  updateRCASection: (rcaId, sectionType, content) =>
    request(`/rca/${rcaId}/sections/${sectionType}`, { method: 'PUT', body: { content } }),
  submitRCA: (rcaId) => request(`/rca/${rcaId}/submit`, { method: 'POST' }),
  submitReview: (rcaId, decision, comment) => request(`/rca/${rcaId}/reviews`, { method: 'POST', body: { decision, comment } }),

  listNotifications: () => request('/notifications'),
  markNotificationRead: (id) => request(`/notifications/${id}/read`, { method: 'POST' }),

  getDashboard: (projectId) => request(`/export/project/${projectId}/dashboard`),
  csvExportUrl: (projectId, filters = {}) => {
    const qs = new URLSearchParams(filters).toString();
    const token = getToken();
    return `${BASE}/export/project/${projectId}/tasks.csv${qs ? `?${qs}` : ''}`;
  },
};

export function setToken(token) {
  localStorage.setItem('teamflow_token', token);
}
export function clearToken() {
  localStorage.removeItem('teamflow_token');
}
export function isLoggedIn() {
  return !!getToken();
}
export { getToken };
