package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class Comment{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long taskId; public Long rcaId; public Long userId; @Column(length=2000) public String body; public LocalDateTime createdAt=LocalDateTime.now(); }
