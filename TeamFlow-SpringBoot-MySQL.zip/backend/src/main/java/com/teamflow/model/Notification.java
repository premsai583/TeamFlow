package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class Notification{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long userId; public String type; public String title; @Column(length=1500) public String message; public boolean readFlag=false; public LocalDateTime createdAt=LocalDateTime.now(); }
