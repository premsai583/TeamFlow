package com.teamflow.model;
import jakarta.persistence.*;
@Entity public class RCASection{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long rcaId; public String sectionType; @Column(length=4000) public String content; }
