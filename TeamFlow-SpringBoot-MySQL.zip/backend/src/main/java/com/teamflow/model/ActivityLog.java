package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class ActivityLog{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long projectId; public Long userId; public String action; @Column(length=1500) public String details; public LocalDateTime createdAt=LocalDateTime.now(); }
