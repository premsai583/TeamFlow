package com.teamflow.model;
import jakarta.persistence.*;
@Entity public class TaskRelation{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long taskId; public Long relatedTaskId; public String relationType; }
