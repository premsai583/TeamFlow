package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class Project{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public String name; @Column(length=1000) public String description; public String viewPreference="kanban"; public LocalDateTime createdAt=LocalDateTime.now(); }
