package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class Task{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long projectId; public String title; @Column(length=2000) public String description; public String status="todo"; public String priority="medium"; public Long assigneeId; public LocalDate dueDate; public Long parentTaskId; public LocalDateTime createdAt=LocalDateTime.now(); public LocalDateTime updatedAt=LocalDateTime.now(); }
