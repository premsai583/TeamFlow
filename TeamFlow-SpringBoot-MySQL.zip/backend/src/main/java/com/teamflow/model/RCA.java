package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class RCA{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long projectId; public String title; public String severity="medium"; public String status="draft"; public Long ownerId; public LocalDateTime createdAt=LocalDateTime.now(); }
