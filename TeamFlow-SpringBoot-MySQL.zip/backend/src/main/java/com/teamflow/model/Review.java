package com.teamflow.model;
import jakarta.persistence.*;import java.time.*;
@Entity public class Review{ @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public Long rcaId; public Long reviewerId; public String decision; @Column(length=1000) public String comment; public LocalDateTime createdAt=LocalDateTime.now(); }
