package com.teamflow.repo; import com.teamflow.model.Project; import org.springframework.data.jpa.repository.JpaRepository; public interface ProjectRepository extends JpaRepository<Project,Long>{}
