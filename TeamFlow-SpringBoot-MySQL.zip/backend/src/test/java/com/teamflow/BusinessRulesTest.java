package com.teamflow;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class BusinessRulesTest{ @Test void reviewCommentIsRequired(){String comment="";assertTrue(comment.isBlank());} @Test void validStatuses(){assertTrue(java.util.List.of("todo","in_progress","blocked","done").contains("todo"));}}
